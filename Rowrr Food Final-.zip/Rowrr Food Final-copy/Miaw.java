import greenfoot.*;

public class Miaw extends Actor {
    private String nama;
    private int score = 0;
    private GreenfootSound eatSound = new GreenfootSound("eat.wav");
    private GreenfootSound hitSound = new GreenfootSound("hit.wav");

    public Miaw(String nama) {
        this.nama = nama;
        setImage("miaw.png");
    }

    public void act() {
        moveWithKeys();
        eatFood();
        hitTrap();
    }

    private void moveWithKeys() {
        if (Greenfoot.isKeyDown("left")) setLocation(getX() - 3, getY());
        if (Greenfoot.isKeyDown("right")) setLocation(getX() + 3, getY());
    }

    private void eatFood() {
        Food food = (Food)getOneIntersectingObject(Food.class);
        if (food != null) {
            eatSound.setVolume(90);
            eatSound.play();
            score += food.getValue();
            getWorld().removeObject(food);
        }
    }

    private void hitTrap() {
        Trap trap = (Trap)getOneIntersectingObject(Trap.class);
        if (trap != null) {
            hitSound.setVolume(90);
            hitSound.play();
            score -= trap.getDamage();
            if (score < 0) score = 0;
            getWorld().removeObject(trap);
        }
    }

    public int getScore() { return score; }
}
