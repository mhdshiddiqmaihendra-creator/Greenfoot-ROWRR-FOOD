public class IceCream extends Food {
    public IceCream() {
        super(15); // skor 15
        try { setImage("icecream.png"); } catch(Exception e) {}
    }
}