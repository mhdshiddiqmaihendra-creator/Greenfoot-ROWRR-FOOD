import greenfoot.*;

public class Meong extends Actor {
    private String nama;
    private int score = 0;
    private GreenfootSound eatSound = new GreenfootSound("eat.wav");
    private GreenfootSound hitSound = new GreenfootSound("hit.wav");

    public Meong(String nama) {
        this.nama = nama;
        setImage("meong.png");
    }

    public void act() {
        moveWithKeys();
        eatFood();
        hitTrap();
    }

    private void moveWithKeys() {
        if (Greenfoot.isKeyDown("a")) setLocation(getX() - 3, getY());
        if (Greenfoot.isKeyDown("d")) setLocation(getX() + 3, getY());
    }

    private void eatFood() {
        Food food = (Food)getOneIntersectingObject(Food.class);
        if (food != null) {
            eatSound.setVolume(90);
            eatSound.play();
            score += food.getValue();
            getWorld().removeObject(food);
        }
    }

    private void hitTrap() {
        Trap trap = (Trap)getOneIntersectingObject(Trap.class);
        if (trap != null) {
            hitSound.setVolume(90);
            hitSound.play();
            score -= trap.getDamage();
            if (score < 0) score = 0;
            getWorld().removeObject(trap);
        }
    }

    public int getScore() { return score; }
}
