public class Knife extends Trap {
    public Knife() {
        super(8);
        setImage("knife.png");
    }
}