import greenfoot.*;

public class Button extends Actor {
    private String label;

    public Button(String text) {
        this.label = text;
        updateImage();
    }

    private void updateImage() {
        GreenfootImage img = new GreenfootImage(label, 24, greenfoot.Color.WHITE, new greenfoot.Color(0, 0, 0, 160));
        setImage(img);
    }
}
