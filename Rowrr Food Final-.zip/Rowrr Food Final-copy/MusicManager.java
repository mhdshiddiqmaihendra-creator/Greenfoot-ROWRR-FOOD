import greenfoot.*;

public class MusicManager {
    private static GreenfootSound bgMusic = new GreenfootSound("bgmusic.wav");
    private static boolean isPlaying = false;

    public static void playMusic() {
        if (!isPlaying) {
            bgMusic.setVolume(35); // Volume musik latar
            bgMusic.playLoop();
            isPlaying = true;
        }
    }

    public static void stopMusic() {
        if (isPlaying) {
            bgMusic.stop();
            isPlaying = false;
        }
    }
}
