import greenfoot.*;

/**
 * Halaman Credit Game "Rowrr Food"
 * Menampilkan nama pembuat, sumber aset, audio, dan inspirasi.
 */
public class CreditScreen extends World {

    public CreditScreen() {
        super(650, 400, 1);
        setBackground("credit_bg.png"); // Pastikan file ada di folder images

        // 🎵 Jalankan musik dari sistem global (agar tidak tumpang tindih)
        MusicManager.playMusic();

        // Judul utama
        showText("🎮 CREDIT GAME 🎮", getWidth() / 2, 70);

        // Nama pembuat
        showText("Luthfi Harisna Mufti (2411523019)", getWidth() / 2, 130);
        showText("Muhammad Shiddiq Maihendra (2411523035)", getWidth() / 2, 160);

        // Sumber aset & audio
        showText("Assets: craftpix.net | pngtree.com", getWidth() / 2, 210);
        showText("Audio: freesound.org | bgmusic.wav", getWidth() / 2, 240);

        // Inspirasi
        showText("Inspired by Drop Food (Pou) & Feeding Frenzy", getWidth() / 2, 290);

        // Petunjuk & tombol kembali
        showText("Press [BACK] or [ESC] to return", getWidth() / 2, 340);
        addObject(new BackButton(), getWidth() / 2, 370);
    }

    public void act() {
        // Tombol ESC untuk kembali ke HomeScreen
        if (Greenfoot.isKeyDown("escape")) {
            MusicManager.stopMusic();
            Greenfoot.setWorld(new HomeScreen());
        }
    }

    @Override
    public void stopped() {
        // Pastikan musik berhenti ketika world diganti
        MusicManager.stopMusic();
    }
}
