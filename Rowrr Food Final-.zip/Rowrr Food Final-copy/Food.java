import greenfoot.*;
import java.util.List;

public class Food extends Actor {
    private int speed = 2;
    private int value;

    public Food(int value) {
        this.value = value;

        // Bentuk default (bisa kamu ganti sesuai gambar aslinya)
        GreenfootImage img = new GreenfootImage(30, 30);
        img.setColor(new Color(255, 255, 200));
        img.fillOval(0, 0, 30, 30);
        setImage(img);
    }

    @Override
    protected void addedToWorld(World world) {
        // Atur posisi acak agar tidak menumpuk di area spawn
        int worldWidth = world.getWidth();
        int x, y;
        boolean posisiBaik;

        do {
            posisiBaik = true;
            x = Greenfoot.getRandomNumber(worldWidth); // posisi X acak
            y = Greenfoot.getRandomNumber(100);        // muncul di area atas (0–100px)

            // Cek agar tidak terlalu dekat dengan makanan lain
            List<Food> semuaMakanan = world.getObjects(Food.class);
            for (Food f : semuaMakanan) {
                if (f != this && Math.abs(f.getX() - x) < 40 && Math.abs(f.getY() - y) < 40) {
                    posisiBaik = false;
                    break;
                }
            }
        } while (!posisiBaik);

        setLocation(x, y);
    }

    public void act() {
        // Gerakan turun seperti Trap
        setLocation(getX(), getY() + speed);

        // Hapus jika melewati batas bawah dunia
        if (getWorld() != null && getY() > getWorld().getHeight() - (getImage().getHeight() / 2)) {
            getWorld().removeObject(this);
        }
    }

    public int getValue() {
        return value;
    }

    public void setSpeed(int s) {
        this.speed = s;
    }
}
