import greenfoot.*;

public class ScoreBoard extends Actor {
    private int score = 0;
    private String label;

    public ScoreBoard(String label) {
        this.label = label;
        update();
    }

    public void add(int points) {
        score += points;
        update();
    }

    private void update() {
        GreenfootImage img = new GreenfootImage(label + score, 24, Color.WHITE, new Color(0,0,0,150));
        setImage(img);
    }
}
