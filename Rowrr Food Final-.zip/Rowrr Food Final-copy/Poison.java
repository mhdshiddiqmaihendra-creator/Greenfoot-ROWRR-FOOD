public class Poison extends Trap {
    public Poison() {
        super(5);
        setImage("poison.png");
    }
}