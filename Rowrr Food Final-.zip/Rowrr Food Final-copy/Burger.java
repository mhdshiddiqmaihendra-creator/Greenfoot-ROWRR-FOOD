public class Burger extends Food {
    public Burger() {
        super(10); // skor 10
        try { setImage("burger.png"); } catch(Exception e) {}
    }
}