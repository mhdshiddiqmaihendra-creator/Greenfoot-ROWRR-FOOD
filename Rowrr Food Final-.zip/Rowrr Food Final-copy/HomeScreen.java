import greenfoot.*;

public class HomeScreen extends World {

    public HomeScreen() {
        super(650, 400, 1);
        setBackground("home_bg.png"); // pastikan file ada di folder images

        // Tombol utama
        addObject(new MainButton(), getWidth()/2, 220);
        addObject(new CreditButton(), getWidth()/2, 280);
    }

    // 🔊 Musik baru mulai saat tombol Run ditekan
    public void started() {
        MusicManager.playMusic();
    }

    // 🔇 Musik berhenti ketika game dijeda/stop
    public void stopped() {
        MusicManager.stopMusic();
    }
}
