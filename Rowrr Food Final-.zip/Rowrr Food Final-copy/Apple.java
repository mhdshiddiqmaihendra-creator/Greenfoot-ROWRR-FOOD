public class Apple extends Food {
    public Apple() {
        super(12); // skor 12
        try { setImage("apple.png"); } catch(Exception e) {}
    }
}