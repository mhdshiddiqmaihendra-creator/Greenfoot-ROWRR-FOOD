import greenfoot.*;

public class CreditButton extends Actor {
    public CreditButton() {
        setImage(new GreenfootImage("Credit", 30, Color.WHITE, new Color(0,0,0,128)));
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new CreditScreen());
        }
    }
}
