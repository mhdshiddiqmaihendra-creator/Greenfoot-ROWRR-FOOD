import greenfoot.*;

public class PlayAgainButton extends Actor {
    public PlayAgainButton() {
        setImage(new GreenfootImage("Main Lagi", 28, Color.WHITE, new Color(0,0,0,150)));
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new StartScreen());
        }
    }
}
