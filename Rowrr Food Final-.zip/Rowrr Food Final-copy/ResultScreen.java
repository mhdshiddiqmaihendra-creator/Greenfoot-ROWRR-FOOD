import greenfoot.*;

public class ResultScreen extends World {

    public ResultScreen(String pemenang, int skor1, int skor2, String nama1, String nama2) {
        super(650, 400, 1); // samakan ukuran dengan world lainnya
        setBackground("background_result.png"); // pastikan file ini ada di folder images

        // Judul hasil pertandingan
        showText("🏆 HASIL PERTANDINGAN 🏆", getWidth() / 2, 80);

        // Skor pemain
        showText(nama1 + ": " + skor1 + " poin", getWidth() / 2, 150);
        showText(nama2 + ": " + skor2 + " poin", getWidth() / 2, 180);

        // Pemenang
        showText("🎉 Pemenang: " + pemenang + " 🎉", getWidth() / 2, 240);

        // Tombol aksi
        addObject(new PlayAgainButton(), getWidth() / 2 - 70, 320);
        addObject(new BackButton(), getWidth() / 2 + 70, 320);

        // Musik tetap aktif agar suasana tidak mati tiba-tiba
        MusicManager.playMusic();
    }

    // 🔇 hentikan musik jika keluar ke world lain (opsional)
    public void stopped() {
        MusicManager.stopMusic();
    }
}
