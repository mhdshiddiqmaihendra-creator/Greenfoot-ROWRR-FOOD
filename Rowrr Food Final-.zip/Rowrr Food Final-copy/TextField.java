import greenfoot.*;  

public class TextField extends Actor {
    private String text = "";
    private boolean focused = false; // untuk mendeteksi apakah sedang aktif diketik
    private int maxLength = 12;

    public TextField() {
        updateImage();
    }

    public void act() {
        checkFocus();
        if (focused) handleTyping();
    }

    /** Mengecek jika TextField diklik */
    private void checkFocus() {
        if (Greenfoot.mouseClicked(this)) {
            focused = true;
        } else if (Greenfoot.mouseClicked(null) && !Greenfoot.mouseClicked(this)) {
            focused = false; // klik di tempat lain = hilang fokus
        }
        updateImage();
    }

    /** Menangani input keyboard */
    private void handleTyping() {
        String key = Greenfoot.getKey();
        if (key == null) return;

        if (key.equals("backspace") && text.length() > 0) {
            text = text.substring(0, text.length() - 1);
        } else if (key.length() == 1 && text.length() < maxLength) {
            text += key;
        }
        updateImage();
    }

    /** Menggambar tampilan teks */
    private void updateImage() {
        GreenfootImage img = new GreenfootImage(200, 30);
        img.setColor(Color.WHITE);
        img.fillRect(0, 0, 200, 30);
        img.setColor(Color.BLACK);
        img.drawRect(0, 0, 200, 30);

        if (focused) {
            img.setColor(Color.BLUE);
            img.drawRect(1, 1, 198, 28); // efek fokus
        }

        img.setColor(Color.BLACK);
        img.drawString(text, 5, 20);
        setImage(img);
    }

    public String getText() {
        return text.trim();
    }

    public void setText(String newText) {
        this.text = newText;
        updateImage();
    }
}
