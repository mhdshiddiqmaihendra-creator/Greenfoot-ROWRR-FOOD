public class HotPan extends Trap {
    public HotPan() {
        super(7);
        setImage("hotpan.png");
    }
}