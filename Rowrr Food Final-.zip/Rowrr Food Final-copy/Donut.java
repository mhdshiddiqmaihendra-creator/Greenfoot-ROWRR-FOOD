public class Donut extends Food {
    public Donut() {
        super(8); // skor 8
        try { setImage("donut.png"); } catch(Exception e) {}
    }
}