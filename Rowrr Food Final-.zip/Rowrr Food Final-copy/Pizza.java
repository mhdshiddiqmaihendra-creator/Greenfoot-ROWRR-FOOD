public class Pizza extends Food {
    public Pizza() {
        super(20); // skor 20
        try { setImage("pizza.png"); } catch(Exception e) {}
    }
}