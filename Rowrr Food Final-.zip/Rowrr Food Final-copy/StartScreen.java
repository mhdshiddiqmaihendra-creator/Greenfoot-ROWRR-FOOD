import greenfoot.*;

public class StartScreen extends World {
    private TextField input1;
    private TextField input2;
    private Button startButton;
    private String nama1 = "";
    private String nama2 = "";

    public StartScreen() {
        super(650, 400, 1);

        // Gunakan background gambar PNG milikmu (pastikan file ada di folder 'images')
        GreenfootImage bg = new GreenfootImage("rowrr_background.png");
        setBackground(bg);

        // --- Posisi elemen form di bawah logo ---
        int centerX = getWidth() / 2;

        showText("Masukkan Nama Pemain 1:", centerX, 180);
        input1 = new TextField();
        addObject(input1, centerX, 210);

        showText("Masukkan Nama Pemain 2:", centerX, 250);
        input2 = new TextField();
        addObject(input2, centerX, 280);

        startButton = new Button("Mulai Game");
        addObject(startButton, centerX, 330);
    }

    public void act() {
        // Cek klik tombol mulai
        if (Greenfoot.mouseClicked(startButton)) {
            nama1 = input1.getText();
            nama2 = input2.getText();

            // Jika nama kosong, beri nama default
            if (nama1.equals("")) nama1 = "Pemain 1";
            if (nama2.equals("")) nama2 = "Pemain 2";

            // Pindah ke dunia permainan
            Greenfoot.setWorld(new FoodWorld(nama1, nama2));
        }
    }
}
