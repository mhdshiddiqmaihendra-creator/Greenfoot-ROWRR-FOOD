public class Bomb extends Trap {
    public Bomb() {
        super(10); // damage 10
        setImage("bomb.png");
    }
}
