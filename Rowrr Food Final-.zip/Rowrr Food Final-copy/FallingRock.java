public class FallingRock extends Trap {
    public FallingRock() {
        super(9);
        setImage("fallingrock.png");
    }
}