import greenfoot.*;

public class FoodWorld extends World {
    private String p1, p2;
    private int timer;
    private int level = 1;
    private final int MAX_LEVEL = 3;

    private Meong meong;
    private Miaw miaw;
    private boolean isLevelStarting = true;
    private int introTimer = 180;
    private int countdownNumber = 3;

    private int foodSpawnDelay = 0;
    private int trapSpawnDelay = 0;

    private int foodSize = 60;
    private int trapSize = 60;
    private int playerSize = 80;

    public FoodWorld(String nama1, String nama2) {
        super(650, 400, 1);
        this.p1 = nama1;
        this.p2 = nama2;

        setTimerByLevel();
        showText("LEVEL " + level + " DIMULAI!", getWidth() / 2, getHeight() / 2);
    }

    public void act() {
        if (isLevelStarting) {
            handleCountdown();
            return;
        }

        if (timer > 0) {
            spawnFood();
            spawnTrap();
            updateTimer();
            updateHUD();
        } else {
            if (level < MAX_LEVEL) nextLevel();
            else {
                showEndResult();
                Greenfoot.stop();
            }
        }
    }

    private void handleCountdown() {
        introTimer--;

        if (introTimer % 60 == 0 && countdownNumber > 0) {
            showText(String.valueOf(countdownNumber), getWidth() / 2, getHeight() / 2);
            countdownNumber--;
        }

        if (introTimer == 20) showText("GO!", getWidth() / 2, getHeight() / 2);

        if (introTimer <= 0) {
            showText("", getWidth() / 2, getHeight() / 2);
            startLevel();
        }
    }

    private void startLevel() {
        isLevelStarting = false;

        if (level == 1) {
            meong = new Meong(p1);
            miaw = new Miaw(p2);

            int playerSize = 70;

            GreenfootImage img1 = meong.getImage();
            img1.scale(playerSize, playerSize);
            meong.setImage(img1);

            GreenfootImage img2 = miaw.getImage();
            img2.scale(playerSize, playerSize);
            miaw.setImage(img2);

            addObject(meong, 150, getHeight() - (playerSize / 2));
            addObject(miaw, 450, getHeight() - (playerSize / 2));
        } else {
            meong.setLocation(150, getHeight() - 50);
            miaw.setLocation(450, getHeight() - 50);
        }

        updateHUD();
    }

    private void spawnFood() {
        foodSpawnDelay--;
        if (foodSpawnDelay > 0) return;

        int chance = level;
        int baseSpeed = level;

        if (Greenfoot.getRandomNumber(100) < chance) {
            Food food;

            if (Greenfoot.getRandomNumber(100) < 2) food = new GoldenApple();
            else {
                switch (Greenfoot.getRandomNumber(5)) {
                    case 0: food = new Apple(); break;
                    case 1: food = new Burger(); break;
                    case 2: food = new Donut(); break;
                    case 3: food = new IceCream(); break;
                    case 4: food = new Pizza(); break;
                    default: food = new Food(10); break;
                }
            }

            food.setSpeed(baseSpeed);

            GreenfootImage img = food.getImage();
            img.scale(foodSize, foodSize);
            food.setImage(img);

            addObject(food, Greenfoot.getRandomNumber(getWidth()), 0);
            foodSpawnDelay = 80 - (level * 10);
        }
    }

    private void spawnTrap() {
        trapSpawnDelay--;
        if (trapSpawnDelay > 0) return;

        int chance = level;
        int baseSpeed = level;

        if (Greenfoot.getRandomNumber(100) < chance) {
            Trap trap;
            switch (Greenfoot.getRandomNumber(5)) {
                case 0: trap = new Bomb(); break;
                case 1: trap = new Knife(); break;
                case 2: trap = new FallingRock(); break;
                case 3: trap = new HotPan(); break;
                case 4: trap = new Poison(); break;
                default: trap = new Bomb(); break;
            }

            trap.setSpeed(baseSpeed);
            GreenfootImage img = trap.getImage();
            img.scale(trapSize, trapSize);
            trap.setImage(img);

            addObject(trap, Greenfoot.getRandomNumber(getWidth()), 0);
            trapSpawnDelay = 90 - (level * 15);
        }
    }

    private void updateTimer() { timer--; }

    private void updateHUD() {
        clearHUD();
        showText(p1 + " | Skor: " + meong.getScore(), 120, 25);
        showText(p2 + " | Skor: " + miaw.getScore(), 530, 25);
        showText(String.valueOf(timer / 60), getWidth() / 2, 25);
        showText("Level " + level, getWidth() / 2, 45);
    }

    private void clearHUD() {
        showText("", 120, 25);
        showText("", 530, 25);
        showText("", getWidth()/2, 25);
        showText("", getWidth()/2, 45);
    }

    private void nextLevel() {
        level++;
        setTimerByLevel();
        isLevelStarting = true;
        introTimer = 180;
        countdownNumber = 3;

        removeObjects(getObjects(Food.class));
        removeObjects(getObjects(Trap.class));

        showText("LEVEL " + level + " DIMULAI!", getWidth() / 2, getHeight() / 2);
    }

    private void setTimerByLevel() {
        switch (level) {
            case 1: timer = 60 * 30; break;
            case 2: timer = 60 * 45; break;
            case 3: timer = 60 * 60; break;
            default: timer = 60 * 30; break;
        }
    }

    private void showEndResult() {
        int s1 = meong.getScore();
        int s2 = miaw.getScore();
        String winner = (s1 > s2) ? p1 : (s2 > s1) ? p2 : "KEDUANYA SERI";

        Greenfoot.setWorld(new ResultScreen(winner, s1, s2, p1, p2));
    }
}
