import greenfoot.*;
import java.util.List;

public class Trap extends Actor {
    private int speed = 3;
    private int damage;

    public Trap(int damage) {
        this.damage = damage;
        GreenfootImage img = new GreenfootImage(30, 30);
        img.setColor(new Color(200, 100, 100));
        img.fillRect(0, 0, 30, 30);
        setImage(img);
    }

    @Override
    protected void addedToWorld(World world) {
        // Pastikan trap tidak muncul terlalu dekat dengan trap lain
        int x, y;
        boolean posisiAman;

        do {
            posisiAman = true;
            x = Greenfoot.getRandomNumber(world.getWidth());
            y = Greenfoot.getRandomNumber(80); // spawn di area atas layar (0–80px)

            List<Trap> jebakanLain = world.getObjects(Trap.class);
            for (Trap t : jebakanLain) {
                if (t != this && Math.abs(t.getX() - x) < 35 && Math.abs(t.getY() - y) < 35) {
                    posisiAman = false;
                    break;
                }
            }
        } while (!posisiAman);

        setLocation(x, y);
    }

    public void act() {
        setLocation(getX(), getY() + speed);

        // Hapus jika melewati batas bawah layar
        if (getWorld() != null && getY() > getWorld().getHeight() - (getImage().getHeight() / 2)) {
            getWorld().removeObject(this);
        }
    }

    public int getDamage() {
        return damage;
    }

    public void setSpeed(int s) {
        this.speed = s;
    }
}
