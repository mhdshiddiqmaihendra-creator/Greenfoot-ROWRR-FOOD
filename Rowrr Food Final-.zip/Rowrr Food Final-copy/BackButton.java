import greenfoot.*;

public class BackButton extends Actor {
    public BackButton() {
        setImage(new GreenfootImage("Back", 25, Color.WHITE, new Color(0,0,0,128)));
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new HomeScreen()); // kembali ke menu utama
        }
    }
}
