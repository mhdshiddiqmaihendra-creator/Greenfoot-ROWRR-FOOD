public class GoldenApple extends Food {
    public GoldenApple() {
        super(50); // skor lebih tinggi dari apel biasa
        try { setImage("golden_apple.png"); } catch(Exception e) {}
    }
}